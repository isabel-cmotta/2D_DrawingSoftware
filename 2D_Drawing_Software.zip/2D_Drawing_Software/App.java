
/**
 * Aplicacao para testar primitivos graficos.
 * 
 * @author Cinthia Alves Barreto, Isabel Cavalcante Motta, Isabella Rubio Venancio
 * @version 14082023
 */
public class App {
    public static void main(String args[]) {
        // Cria e define dimensao da janela (em pixels)
        //new Gui(1500, 1000); 
        new Gui(1300, 1000); 
    }
}
